#include <time.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdio.h>

typedef struct parameter
{
  int *input_array;
  int start;
  int end;
  int threads_in;
  int elements_in;
  int max_result;
}Parameter;

int fill_array();
int print_results();
int sum();
int max_helper(Parameter *p );
void * max(void *p);
int true_max = 0;

void * max(void *p){
   Parameter* par = p;
   int i = par->start;
   int max = par->input_array[i];
   for (i = par->start + 1; i <= par->end; i++){
      if(max < par->input_array[i]){
	       max = par->input_array[i];
      }
   }
   if(true_max < max){
      true_max = max;
   }
}


int main(){
   int elements,threads,seed,task;      /*,sum_result;*/
   char result;
   int *element_array;
   pthread_t *thread_array;
   Parameter par;

   do{

      printf("Number of Element?: ");
      scanf("%d",&elements);
      par.elements_in = elements;

   } while(elements < 0 );

   element_array = calloc(elements,sizeof(int));


   do{
      printf("Number of threads?: ");
      scanf("%d",&threads);
      par.threads_in = threads;
    
   } while(threads < 0 );

   thread_array = calloc(threads,sizeof(pthread_t));

   do{
      
      printf("Seed?: ");
      scanf("%d",&seed);
      
   } while(seed < 0 );
   
   do{

      printf("Task 1 or 2 ?: ");
      scanf("%d",&task);
      
   }while(task != 1 && task != 2);


   do{
      printf("Print results?: ");
      scanf("%c",&result);
      
   }while( result != 'y' && result != 'n' );
   
   
   srand(seed);

   /*fill array with elements */
   fill_array(element_array, elements);
   
   par.input_array = element_array;

   if(task == 1){
      
       for(i = 0; i < par.threads_in; i++){
	 pthread_create(&thread_array[i],NULL, max, &par);
	 
	 }
		      
      if(result == 'y'){
	 printf("result: %d" ,par.max_result); 

      }
   }


   if(task == 2 ){

      /*sum_result = sum(); */


   }
         return 0;
}




int fill_array(int *element_in,int items){
   int i;
   for(i = 0; i < items; i++){
      
      element_in[i] = rand();
  
   }
   return 0;
}


/*
int print_results(){





}


int sum(){
   int i;
   int sum_array = 0;

   for(i = 0; i < elements; i++){

       sum_array = sum_array + element_array[i];

   }
    return sum_array;
}


*/
/*int max_helper(Parameter *p){
  int i;
  int startpoint;
  int endpoint;
  int maxhelper_max = 0;
  int compare;
  
  p->start = startpoint;
  p->end = endpoint;

  for(i = startpoint; i < endpoint; i++){
     compare = p->input_array[i];
     if(compare > maxhelper_max){
	maxhelper_max = p->input_array[i];
     }  
  }
   
  if(maxhelper_max > p->max_result){
     p->max_result = maxhelper_max;
  }

  return 0;
  }*/

int max(Parameter *p ){

      int i;
      if( p->threads > p->ratio){

         int ratio = 1;

      }else{
        
        int ratio = element / threads;

      }
      
      int amount = elements / ratio;
      int max = 0;
      p->start= 0;
      p->end = ratio - 2;
      
      if(ratio = 1 ){
        end = start + 1;

      }
     

  for(i = 0; i < p->threads_in; i++){
    
    pthread_create(&thread_array[i],NULL,&max_helper,NULL);

    if(p->elements_in % p->threads_in == 0  && p->threads_in != 0 ){

       p->start = p->end +1 ;
       p->end =  p->start + ratio -1;
    }


    if(elements % threads != 0  && i = threads -2 && threads != 0){
       
       p->start = p->end +1 ;
       p->end =  p->start + ratio -1;
    }

    if(ratio = 1){

     p->start = p->end;
     p->end  = p->end +1


    }

      
     
  }
  
      return p->max_result;

}


*/