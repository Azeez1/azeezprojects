#include <stdio.h>
#include <stdlib.h>
#include <sysexits.h> 

int number_of_threads;
int number_of_elements;
int seed;
int *array;
int index;
int task;
char results;
int *new_array;
pthread_t threads;

void max(int index);

int main(int argc, char *argv[]) { 

	printf("How many elements in the array?");
	scanf("%d", &number_of_elements);

	printf("How many threads?");
	scanf("%d", &number_of_threads);

	printf("Provide seed.");
	scanf("%d", &seed);

	printf("Enter '1' for MAX, '2' for SUM");
	scanf("%d", &task);

	printf("Would you like the results printed? (Y or N)");
	scanf("%c", &results);

	/* set seed for random generator */
	srand(seed);

	/* dynamically allocate size of array */
	array =(int*)malloc(number_of_elements * sizeof(int)); 

	/* get new array ready */
	new_array =(int*)malloc(number_of_elements * sizeof(int)); 

	/* create array for threads */
	threads =(pthread_t*)malloc(number_of_threads * sizeof(pthread_t)); 

	/* set elements in array to random values */
	for (index = 0; index < number_of_elements; index++) {
		array[index] = rand();
	}

	/* compute max */
	if (task == 1) {
		for (index = 0; index < number_of_threads; index++) {
			pthread_create(&(threads[i]),NULL, &max, &index);
		}
	/* compute sum */
	} else {

	}


}

void max(int index) {
	/* create segment of array based off of index and total number of threads */
	
}











