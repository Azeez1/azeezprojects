/*  
	Azeez Saba
    UID: 112407605
    Directory ID: asaba1

    htable.c
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "htable.h"

unsigned int hash_code(const char *key);
int key_exists(const Table *table, const char *key);
static void free_bucket(Table *table, Bucket *bucket);

/*computes the hash code*/
unsigned int hash_code(const char *key) {
	unsigned int code;
	for(code=0 ; *key; key++) {
    	code ^= ((code << 3) | (code >> 29)) + (*key);
  	}
  	return code;
}

/*returns 1 if key exists in the table, 0 if otherwise*/
int key_exists(const Table *table, const char *key) {
	Bucket *current;

	current = table->buckets[hash_code(key) % table->table_size];
	while (current != NULL) {
		if (strcmp(current->key, key) == 0) {
			return 1;
		} else {
			current = current->next;
		}
	}

	/*doesn't exist*/
	return 0;
}

/*allocates table structure and initializes fields*/
int create_table(Table **table, int table_size, void (*free_value)(void *)) {
	int i;

	if (table == NULL || table_size == 0) {
		return FAILURE;
	}

	*table = malloc(sizeof(Table));
	(*table)->buckets = calloc(table_size, sizeof(Bucket *));

	/*initializes each array entry to NULL*/
	for (i = 0; i < table_size; i++) {
		(*table)->buckets[i] = NULL;
	}

	(*table)->free_value = free_value;
	(*table)->table_size = table_size;
	(*table)->key_count = 0;

	return SUCCESS;

}

/*destroys entire table*/
int destroy_table(Table *table) {
	int i;
	i = clear_table(table);
	if (i == FAILURE) {
		return FAILURE;
	}
	free(table->buckets);
	free(table);
	return SUCCESS;

}

/*attempts to insert a key/value pair into the table*/ 
int put(Table *table, const char *key, void *value) {
	Bucket *current;
	Bucket *new;

	if (table == NULL || key == NULL) {
			return FAILURE;
	}

	/*if key exists, search through to replace value*/
	if (key_exists(table, key)) {
		current = table->buckets[hash_code(key) % table->table_size];
		while (current != NULL) {
			if (strcmp(current->key, key) == 0) {
				/*free value*/
				if (current->value != NULL && table->free_value != NULL) {
					table->free_value(current->value);
				}
				/*replace*/
				current->value = value;
				return SUCCESS;
			} else {
				current = current->next;
			}
		}	
	/*if key doesn't exist, attempt to add to beginning of chain*/	
	} else {
		/*if a chain of buckets doesn't exist yet*/
		if (table->buckets[hash_code(key) % table->table_size] == NULL) {
			new = malloc(sizeof(Bucket));
			if (new == NULL) {
				return FAILURE;
			}
			new->key = malloc(sizeof(key));
			strcpy(new->key, key);
			new->value = value;
			new->next = NULL;
			table->buckets[hash_code(key) % table->table_size] = new;
			(table->key_count)++;
			return SUCCESS;

		/*chain already exists. Add to beginning of chain*/
		} else {
			current = table->buckets[hash_code(key) % table->table_size];
			new = malloc(sizeof(Bucket));
			if (new == NULL) {
				return FAILURE;
			}
			new->key = malloc(sizeof(key));
			strcpy(new->key, key);
			new->value = value;
			new->next = current;
			table->buckets[hash_code(key) % table->table_size] = new;
			(table->key_count)++;
			return SUCCESS;
		}
	}

	return FAILURE;

}

/* Returns value of associated key */
int get_value(const Table *table, const char *key, void **value) {
	Bucket *current;
	if (table == NULL || key == NULL) {
		return FAILURE;
	} else {
		/* Key does not exist in the given table */
		if (!key_exists(table, key)) {
			*value = NULL;
			return FAILURE;

		} else {
			current = table->buckets[hash_code(key) % table->table_size];
			while (current != NULL) {
				/* Found key. */
				if (strcmp(current->key, key) == 0) {
					*value = current->value;
					return SUCCESS;
				} else {
					current = current->next;
				}
			}
		}
	}

	return FAILURE;
}

/*returns key count of the table*/
int get_key_count(const Table *table) {

	if (table == NULL) {
		return FAILURE;
	}

	return table->key_count;
}

/*attempts to remove the bucket associated with the key*/
int remove_entry(Table *table, const char *key) {
	Bucket *current;
	Bucket *previous = NULL;

	if (table == NULL || key == NULL) {
		return FAILURE;
	}

	if (!key_exists(table, key)) {
		return FAILURE;
	}

	current = table->buckets[hash_code(key) % table->table_size];
	while (current != NULL) {
		if (strcmp(current->key, key) == 0) {
			/* Found the key in the first bucket of the chain */
			if (previous == NULL) {
				table->buckets[hash_code(key) % table->table_size] = 
				current->next;
				free_bucket(table, current);
				return SUCCESS;
			} else {
				previous->next = current->next;
				free_bucket(table, current);
				return SUCCESS;
			}
		/* Key is not in the current bucket, try next one */
		} else {
			previous = current;
			current = current->next;
		}
	}

	return FAILURE;

}

/* Clears entire table */
int clear_table(Table *table) {
	int i;
	Bucket *current = NULL;
	Bucket *previous = NULL;
	int found = 0;

	if (table == NULL) {
		return FAILURE;
	}

	/*Loop through every bucket */
	for (i = 0; i < table->table_size; i++) {

		while (table->buckets[i] != NULL) {
			found = 0;
			current = table->buckets[i];
			while (current->next != NULL) {
				found = 1;
				previous = current;
				current = current->next;
			}
			
			free_bucket(table, current);
			/* If current->next == NULL */
			if (found == 0) {
				
				previous = NULL;
			}
			
			if (previous != NULL) {
				previous->next = NULL;
			} else {
				table->buckets[i] = NULL;
			}
		}
	}


	return SUCCESS;
}

/*return SUCCESS if table is NULL or empty, 0 if otherwise*/
int is_empty(const Table *table) {
	if (table == NULL) {
		return SUCCESS;
	}

	if (get_key_count(table) == 0) {
		return SUCCESS; 
	}

	return 0;
}

/*fully deallocates the memory associated with the bucket*/
static void free_bucket(Table *table, Bucket *bucket) {
	if (bucket->key != NULL) {
		free(bucket->key);
		(table->key_count)--;
		bucket->key = NULL;
	}

	if (bucket->value != NULL && table->free_value != NULL) {
		table->free_value(bucket->value);
		bucket->value = NULL;
	}

	bucket->next = NULL;

	free(bucket);
	bucket = NULL;

}

/*returns the size of the table*/
int get_table_size(const Table *table) {
	if (table == NULL) {
		return FAILURE;
	}  

	return table->table_size;
}