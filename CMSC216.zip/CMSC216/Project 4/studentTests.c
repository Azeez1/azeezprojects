/*  
   Marcellus Davenport
    UID: 112407605
    Directory ID: asaba1

    studentTests.c
*/

#include <stdio.h>
#include <stdlib.h>
#include "htable.h"
#include "my_memory_checker_216.h"

/*****************************************************/
/* In this file you will provide tests to your       */
/* hash table.  Each test should be named test1()    */
/* test2(), etc. Each test must have a description   */
/* of what it is testing (this description is really */
/* important).                                       */
/*                                                   */
/* You can tell whether any test failed if you       */
/* execute on the command line "echo $?" and you get */
/* a value other than 0. "echo $?" prints the status */
/* of the last command.                              */
/*                                                   */
/* main just calls all test1(), test2(), etc.        */
/*****************************************************/


/* Tests key_count() */
static int test1() {
   Table *table;
   int size = 10;
   int value1 = 15;
   int value2 = 15;

   printf("Test 1:\n");
   create_table(&table, size, NULL);
   put(table, "bob", &value1);
   put(table, "steven", &value2);


   if (get_key_count(table) != 2) {
      printf("Table holds incorrect key-count.\n");
      return FAILURE;
   }
   printf("Table holds correct key-count.\n");

   destroy_table(table);

   return SUCCESS;
}

/* Tests if "put" works */
static int test2() {
   Table *table;
   int size = 10;
   int value = 15;
   void *returned_value;

   int result;

   printf("Test 2:\n");
   create_table(&table, size, NULL);
   result = put(table, "bob", &value);

   /*checks for insert error*/
   if (result == FAILURE) {
      printf("Table failed to insert the key 'bob'\n");
      return FAILURE;
   }
   printf("Insert was successful\n");

   result = get_value(table, "bob", &returned_value);
   /*checks for get_value error*/
   if (result == FAILURE) {
      printf("Failed to retrieve the value.\n");
      return FAILURE;
   }
   printf("Retrieving the value succeeded.\n");

   if (value != *(int *)returned_value) {
      printf("Table holds an incorrect value for the key 'bob'\n");
      return FAILURE;
   }
   printf("Table holds the correct value for the key 'bob'\n");

   destroy_table(table);

   return SUCCESS;
}

/* 
   Tests if clear_table() releases all values 
   Also checks is_empty()
*/
static int test3() {
   Table *table;
   int size = 10;
   int value1 = 15;
   int value2 = 15;

   printf("Test 3:\n");

   create_table(&table, size, NULL);
   put(table, "bob", &value1);
   put(table, "steven", &value2);

   printf("Attempting to clear the table.\n");
   if (clear_table(table) == FAILURE) {
      printf("Table failed to clear. \n");
   }

   if (!is_empty(table)) {
      printf("Table failed to clear.\n");
      return FAILURE;
   }

   printf("Table cleared successfully.\n");

   destroy_table(table);

   return SUCCESS;
}

/* Tests remove_entry() */
static int test4() {
   Table *table;
   int size = 10;
   int value1 = 15;
   int value2 = 15;
   void *returned_value;

   printf("Test 4:\n");
   create_table(&table, size, NULL);
   put(table, "bob", &value1);
   put(table, "steven", &value2);

   remove_entry(table, "bob");
   /* should not be able to find the key */
   if (get_value(table, "bob", &returned_value) ==
      SUCCESS) {
      printf("Entry wasn't removed from the table.\n");
      return FAILURE;
   }
   printf("Entry was successfully removed from the table.\n");

   destroy_table(table);

   return SUCCESS;
}

/* Tests for get_table_size() */
static int test5() {
   Table *table;
   int size = 10;

   printf("Test 5:\n");

   create_table(&table, size, NULL);

   if (get_table_size(table) != size) {
      printf("Table holds incorrect table size\n");
      return FAILURE;
   }
   printf("Table holds correct table size.\n");

   destroy_table(table);

   return SUCCESS;
}


int main() {
   int result = SUCCESS;

   /***** Starting memory checking *****/
   start_memory_check();
   /***** Starting memory checking *****/

   if(test1() == FAILURE) result = FAILURE;
   if(test2() == FAILURE) result = FAILURE;
   if(test3() == FAILURE) result = FAILURE;
   if(test4() == FAILURE) result = FAILURE;
   if(test5() == FAILURE) result = FAILURE;

   /****** Gathering memory checking info *****/
   stop_memory_check();
   /****** Gathering memory checking info *****/
   
   if(result == FAILURE) {
      exit(EXIT_FAILURE);
   }

   return EXIT_SUCCESS;
}
