/*   Azeez Saba
    112407605
    asaba1
*/

#include <stdio.h>
#include <stdlib.h>
#include <sysexits.h> 
#include <string.h>
#include <errno.h> 
#include "hashtable.h"

#define MAX_FILE_LEN 1024
#define INSERT 1
#define SEARCH 2
#define DELETE 3
#define RESET 4
#define DISPLAY 5

static void strip_command(char *line, char *command);
static int return_command_code(char *command);
static void perform_task(Table *t, int command_code, char *line);
static void set_key_value(char *line, char *key, char *value);
static void return_value(char *line, char *value);

int main(int argc, char *argv[]) {

	Table t;
	FILE *input; /*used if a FILE is specified*/
	char line[MAX_FILE_LEN] = " "; /*stores each line when encountered*/
	char command[MAX_FILE_LEN] = " ";

	/* Initialize the table */
  	init_table(&t);

	/* To figure out which input to use */
   if (argc == 1) {
   	input = stdin;   /* input = standard input (keyboard) */
   	while (fgets(line, MAX_FILE_LEN, input) != NULL) {
      	/*line holds current line*/

      	if (line[0] == '\n') {
      		continue;
      	}
      	strip_command(line, command);
       	perform_task(&t, return_command_code(command), line);
    }

   } else if (argc == 2) { 
   		/* Use the file the user passed in */
   		if ((input = fopen(argv[1], "r")) == NULL) {
      		fprintf(stderr, "File failed. Error: %s\n", strerror(errno));
      		return EX_OSERR;
      		
      		      
   		} else {
      		while (fgets(line, MAX_FILE_LEN, input) != NULL) {
      			/*line holds current line*/

      			if (line[0] == '\n') {
      				continue;
      			}

      			strip_command(line, command);
        		perform_task(&t, return_command_code(command), line);

        	}
    	} 
    	fclose(input);
    	exit(EXIT_SUCCESS);
   } else {
      return EX_USAGE;   
   }

   return 0;

}

/*returns the first word of the line*/
static void strip_command(char *line, char *command) {

	sscanf(line,"%s", command);

}

/*returns a code denoting which action to take place 
  depending on what the first word of the line is*/
static int return_command_code(char *command) {
	if (strcmp(command, "insert") == 0) {
		return INSERT;
	} else if (strcmp(command, "search") == 0) {
		return SEARCH;
	} else if (strcmp(command, "delete") == 0) {
		return DELETE;
	} else if (strcmp(command, "reset") == 0) {
		return RESET;
	} else if (strcmp(command, "display") == 0) {
		return DISPLAY;
	} else {
		/*first string is '#'*/
		return 0;
	}

}

/*carries out the actual task*/
static void perform_task(Table *t, int command_code, char *line) {

	char key[MAX_FILE_LEN] = " "; /*holds key*/
	char value[MAX_FILE_LEN] = " "; /*holds value*/
	
	int i = 0;
	set_key_value(line, key, value);

	if (command_code == INSERT) {
		/*insert*/
		if (insert(t, key, value) == 0) {
			/*SUCCESS*/
			printf("Insertion of %s => %s succeeded.\n", key, value);
			return;
		} else {
			/*FAILURE*/
			printf("Insertion of %s => %s failed.\n", key, value);
			return;

		}
	} else if (command_code == SEARCH) {
		if (search(t, key, value) == 0) {
			/*found key*/
			printf("Search for %s succeeded (%s).\n", key, value);
			return;

		} else {
			/*didn't find key*/
			printf("Search for %s failed.\n", key);
			return;

		}
	} else if (command_code == DELETE) {
		/*delete*/
		if (delete(t, key) == 0) {
			/*delete successful*/
			printf("Deletion of %s succeeded.\n", key);
			return;

		} else {
			/*delete unsuccessful*/
			printf("Deletion of %s failed.\n", key);
			return;

		}
	} else if (command_code == RESET) {
		/*reset*/
		reset_table(t);
		printf("Table reset.\n");
	} else if (command_code == DISPLAY) {
		/*display*/
		return_value(line, value);
		if (strcmp(value, "key_count") == 0) {
			/*value = key_count*/
			printf("Key count: %d\n", t->key_ct);
		} else {
			/*value = table*/
			for (i = 0; i < bucket_count(t); i++) {
				if (t->buckets[i].state == EMPTY) {
					printf("Bucket %d: %s\n", i, "EMPTY");
				} else if (t->buckets[i].state == FULL) {
					printf("Bucket %d: %s (%s => %s)\n", i, "FULL", t->buckets[i].data.key, 
						t->buckets[i].data.value);
				} else {
					/*deleted*/
					printf("Bucket %d: %s\n", i, "DELETED");
				}
			}
		}
	} else {
		/*reached a comment
		  ignore this line*/
	}
}

/*sets keys and values*/
static void set_key_value(char *line, char *key, char *value) {

	char command[MAX_FILE_LEN] = " ";

	sscanf(line,"%s %s %s", command, key, value);

}

/*sets value*/
static void return_value(char *line, char *value) {

	char command[MAX_FILE_LEN] = " ";

	sscanf(line, "%s %s", command, value);
}











