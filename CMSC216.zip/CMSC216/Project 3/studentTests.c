/*  Azeez Saba
    112407605
    asaba1
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hashtable.h"

/*****************************************************/
/* In this file you will provide tests to your       */
/* hash table.  Each test should be named test1()    */
/* test2(), etc. Each test must have a description   */
/* of what it is testing (this description is really */
/* important).                                       */
/*                                                   */
/* You can tell whether any test failed if you       */
/* execute on the command line "echo $?" and you get */
/* a value other than 0. "echo $?" prints the status */
/* of the last command.                              */
/*                                                   */
/* main just calls all test1(), test2(), etc.        */
/*****************************************************/


/*tests search */
static int test1() {
   Table table;
   char value[MAX_STR_SIZE + 1];

   init_table(&table);
   /*adds key (snapchat) paired with value (nice)*/
   if (insert(&table, "snapchat", "nice") != SUCCESS) {
       return FAILURE;
   }

   /*looks for key (snapchat) and adds that val into value*/
   if (search(&table, "snapchat", value) != SUCCESS) {
      return FAILURE;
   } 

   /*checks if value = "nice"*/
   if (strcmp(value, "nice")) {
      return SUCCESS;
   } else {
      return FAILURE;
   }
   
}

/*tests delete*/
static int test2() {
   Table table;
   char value[MAX_STR_SIZE + 1];

   init_table(&table);
   /*adds key (snapchat) paired with value (nice)*/
   if (insert(&table, "snapchat", "nice") != SUCCESS) {
       return FAILURE;
   }

   /*deletes key (snapchat)*/
   if (delete(&table, "snapchat") != SUCCESS) {
       return FAILURE;
   }

   /*looks for key (snapchat)
     it shouldn't be there
   */
   if (search(&table, "snapchat", value) == SUCCESS) {
      return FAILURE;
   } 

   return SUCCESS;

}

/*tests key_count*/
static int test3() {
   Table table;
   init_table(&table);

   /*adds key (snapchat) paired with value (nice)*/
   if (insert(&table, "snapchat", "nice") != SUCCESS) {
      return FAILURE;
   }

   /*adds key (snapchat) paired with value (nice)*/
   if (insert(&table, "bob", "harry") != SUCCESS) {
      return FAILURE;
   }

   /*adds key (snapchat) paired with value (nice)*/
   if (insert(&table, "jill", "max") != SUCCESS) {
       return FAILURE;
   }

   if (key_count(&table) != 3) {
      return FAILURE;
   }

   return SUCCESS;
}

int main() {
   int result = SUCCESS;

   if (test1() == FAILURE) {
      result = FAILURE;
   } 

   if (test2() == FAILURE) {
      result = FAILURE;
   }

   if (test3() == FAILURE) {
      result = FAILURE;
   }
   
   if (result == FAILURE) {
      exit(EXIT_FAILURE);
   } 

   /*all tests passed*/
   return EXIT_SUCCESS;
}