/*   Azeez Saba
    112407605
    asaba1
*/

#include <stdio.h>
#include <string.h>
#include "hashtable.h"

int loop_again(const char *key);

/*returns the number of keys present in the table
  returns -1 if the table is NULL
*/
int key_count(Table *table) {
	if (table == NULL) {
		return FAILURE;
	} else {
		return table->key_ct;
	}
}

/*returns the number of buckets the table has
  returns -1 if the table is NULL
*/
int bucket_count(Table *table) {

	if (table == NULL) {
		return FAILURE;
	}

	return NUM_BUCKETS;
}

/*initializes table to empty*/
void init_table(Table *table) {

	int i;
	table->key_ct = 0;
	if (table != NULL) {
		for (i = 0; i < NUM_BUCKETS; i++) {
			table->buckets[i].state = EMPTY;
		}
	}
}

/*reset the table to an empty state*/
void reset_table(Table *table) {

	/*same functionality*/
	init_table(table);
}
/*searches for key in the table*/
int search(Table *table, const char *key, char *val) {

	long i;
	int loop = loop_again(key);

	/*begins indexing where the key is supposed to be*/
	for (i = hash_code(key) % NUM_BUCKETS; i < NUM_BUCKETS; i++) {
		if (table->buckets[i].state  == FULL) {
			if (strcmp(table->buckets[i].data.key,key) == 0) {
				if (val == NULL) {
					return SUCCESS;
				}
				strcpy(val,table->buckets[i].data.value);
				return SUCCESS;
			}
		}
	}

	/*couldnt find key, so starts from the beginning*/
	if (loop) {
		for (i = 0; i < NUM_BUCKETS; i++) {
			if (table->buckets[i].state  == FULL) {
				if (strcmp(table->buckets[i].data.key,key) == 0) {
					if (val == NULL) {
						return SUCCESS;
					}
					strcpy(val,table->buckets[i].data.value);
					return SUCCESS;
				}
			}					
		}
	} 

	/*couldn't find key*/
	return -1;
}

/*computes hashcode from given string*/
unsigned long hash_code(const char *str) {
	
	int i;
	long hash = 0;
	if (str == NULL) {
		return SUCCESS;
	} else {
		if (strlen(str) == 0) {
			return SUCCESS;
		} else {
			for (i = 0; i < strlen(str); i++) {
				if (i == 0) {
					hash += str[i]; 
				} else {
					hash *= 65599;
					hash += str[i];
				}
			}
		}
	}

	return hash;
}

int insert(Table *table, const char *key, const char *val) {

	/*checks if the algorithm needs to loop again*/
	int loop = loop_again(key);
	long i;

	/*returns failure if key, val, or table is NULL*/
	if (key == NULL || val == NULL || table == NULL) {
		return FAILURE;
	} 

	if (strlen(key) > MAX_STR_SIZE || strlen(val) > MAX_STR_SIZE) {
		return FAILURE;
	}

	/*begins indexing where the key is supposed to be*/
	for (i = hash_code(key) % NUM_BUCKETS; i < NUM_BUCKETS; i++) {
		if (strcmp(table->buckets[i].data.key, key) == 0) {
			/*Keys are the same. Just replace the value*/
			strcpy(table->buckets[i].data.value,val);
			return SUCCESS; /*insert was successful*/
		}
		if (table->buckets[i].state != FULL) {
			strcpy(table->buckets[i].data.key,key);
			strcpy(table->buckets[i].data.value,val);
			table->buckets[i].state = FULL;
			(table->key_ct)++;
			return SUCCESS; /*insert was successful*/
		}
	}

	/*Didn't insert. Start in the front of the array this time*/
	if (loop) {
		for (i = 0; i < NUM_BUCKETS; i++) {
			if (strcmp(table->buckets[i].data.key, key) == 0) {
				/*Keys are the same. Just replace the value*/
				strcpy(table->buckets[i].data.value,val);
				return SUCCESS; /*insert was successful*/	
			}
			if (table->buckets[i].state != FULL) {
				strcpy(table->buckets[i].data.key,key);
				strcpy(table->buckets[i].data.value,val);
				table->buckets[i].state = FULL;
				(table->key_ct)++;
				return SUCCESS; /*insert was successful*/
			}
		}
	}

	return FAILURE; /*Every bucket is FULL*/
}

int delete(Table *table, const char *key) {
	
	long i;

	/*return failure if key or table is NULL*/
	if (key == NULL || table == NULL) {
		return FAILURE;
	}

    /*begins indexing where the key is supposed to be*/
	for (i = hash_code(key) % NUM_BUCKETS; i < NUM_BUCKETS; i++) {
		if (table->buckets[i].state  == FULL) {
			if (strcmp(table->buckets[i].data.key,key) == 0) {
				table->buckets[i].state = DELETED;
				(table->key_ct)--;
				return SUCCESS;
			}
		}
	}

	/*couldnt find key, so starts from the beginning*/
	for (i = 0; i < NUM_BUCKETS; i++) {
		if (strcmp(table->buckets[i].data.key,key) == 0) {
			if (table->buckets[i].state  == FULL) {
				table->buckets[i].state = DELETED;
				(table->key_ct)--;
				return SUCCESS;
			}
		}
	}

	return -1; /*Couldn't find the key*/
}

char

/*checks if needs to loop again*/
int loop_again(const char *key) {
	if (hash_code(key) % NUM_BUCKETS == 0) {
		return 0;
	}

	return 1;
}









