/*  Azeez saba
    112407605
    asaba1
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sysexits.h>
#include <err.h>
#include <fcntl.h>
#include "executor.h"
#include "command.h"

static void print_tree(struct tree *t);

int execute(struct tree *t) {

 	pid_t child_pid;
 	int input_fd, output_fd;
 	int status;
 	int pipe_fd[2];
 	pid_t pipe_process;
 	int status2;
  
 	/* first check if the tree is NULL */
  	if (t == NULL) {
    	return 0;
  	}

  	/* conjunction == none */
  	if (t->conjunction == NONE) {
    
   
    	if (strcmp(t->argv[0], "exit") == 0) {
      		exit(0);
    	}
    
    	if (strcmp(t -> argv[0], "cd") == 0) {
      		if (t->argv[1] != NULL) {
      			chdir(t->argv[1]);
				return 0;
      		} else {
				chdir(getenv("HOME"));
				return 0;
      		}
    	}

    	if ((child_pid = fork()) < 0) {
    		err(EX_OSERR, "Error: Fork Error.");
    	} else 

		/* child */
    	if (child_pid == 0) {

			/* input redirection */
			if (t->input != NULL) {
	  			 if ((input_fd = open(t->input, O_RDONLY)) < 0) {
	  				err(EX_OSERR, "Error: Error Opening File.");
	  			}
	  
	  			if (dup2(input_fd, STDIN_FILENO) < 0) {
	    			err(EX_OSERR, "Error: dup2 Error.");
	  			}

	  			if (close(input_fd) < 0) {
	    			err(EX_OSERR, "Error: Error Closing File.");
	  			}
			}

			/* output redirection */
			if (t->output != NULL) {
	  			if ((output_fd = open(t -> output, O_RDWR | O_CREAT | O_TRUNC, 0664)) < 0) {
	  				err(EX_OSERR, "Error: Error Opening File.");
	  			}

	  			if (dup2(output_fd, STDOUT_FILENO) < 0) {
	    			err(EX_OSERR, "Error: dup 2 Error.");
	  			}

	  			if (close(output_fd) < 0) {
	    			err(EX_OSERR, "Error: Error Closing File.");
	  			}
			}

			execvp(t->argv[0], t->argv);
			printf("Failed to execute %s\n", t->argv[0]);
			exit(EXIT_FAILURE); 

		/* parent */
    	} else {
			wait(&status);
			return status;
    	}
    }


    /* conjunction == AND */
  	if (t->conjunction == AND) {

  		if ((child_pid = fork()) < 0) {
    		err(EX_OSERR, "Error: Fork Error.");
    	} else 

		/* child */
    	if (child_pid == 0) {
			/* input redirection */
			if (t->input != NULL) {
	  			if ((input_fd = open(t->input, O_RDONLY)) < 0) {
	  				err(EX_OSERR, "Error: Error Opening File.");
	  			}
	  
	  			if (dup2(input_fd, STDIN_FILENO) < 0) {
	    			err(EX_OSERR, "Error: dup2 Error.");
	  			}

	  			if (close(input_fd) < 0) {
	    			err(EX_OSERR, "Error: Error Closing File.");
	  			}
			}

			/* output redirection */
			if (t->output != NULL) {
	  			if ((output_fd = open(t -> output, O_RDWR | O_CREAT | O_TRUNC, 0664)) < 0) {
	  				err(EX_OSERR, "Error: Error Opening File.");
	  			}

	  			if (dup2(output_fd, STDOUT_FILENO) < 0) {
	    			err(EX_OSERR, "Error: dup 2 Error.");
	  			}

	  			if (close(output_fd) < 0) {
	    			err(EX_OSERR, "Error: Error Closing File.");
	  			}
			}

			if ((execute(t -> left) == 0) && (execute(t -> right) == 0)) {
				exit(EXIT_SUCCESS);
			} else {
				exit(EXIT_FAILURE);
				/* find macro for error */ 
			}
		/* parent */
    	} else {
    		wait(&status);
			return status;
    	}
    } 


    /* conjunction == PIPE */
	if (t->conjunction == PIPE) {

    	/* check for fork errors */
   		if ((child_pid = fork()) < 0) {
    		err(EX_OSERR, "Error: Fork Error.");
    	}

    	/* child */
    	if (child_pid == 0) {

      		/* check for errors */
      		if (pipe(pipe_fd) < 0) {
				err(EX_OSERR, "Error: Pipe Error.");
      		} else {
      			if ((pipe_process = fork()) < 0) {
      				err(EX_OSERR, "Error: Fork Error.");
      			/* child of pipe process*/
      			} else if (pipe_process == 0) {
      				/* child doesn't need to read */
      				close(pipe_fd[0]);

      				if (dup2(pipe_fd[1], STDOUT_FILENO) < 0) {
	  					err(EX_OSERR, "Error: dup2 Error.");
					}

					exit(execute(t -> left));

      			/* parent of pipe process */
      			} else {
					wait(&status);
					if(status != 0) {
	  					exit(EXIT_FAILURE);
					}
					/* parent doesn't need to write */
					close(pipe_fd[1]);

					/* places whatever is read from the pipe into STDIN */
					/* checks for errors */
					if (dup2(pipe_fd[0], STDIN_FILENO) < 0) {
	 					err(EX_OSERR, "Error: dup2 Error.");
					}

					/*execute right side of pipe */
					exit(execute(t->right));
      			}
      		}
      	/* parent */ 
      	} else {
      		wait(&status2);
      		return status2;
      	} 
    } 
  
	return 0;

}